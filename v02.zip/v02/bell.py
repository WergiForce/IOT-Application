from gpiozero import LED, Button
from picamera import PiCamera
from email.mime.text import MIMEText
from email.mime.image import MIMEImage
from email.mime.multipart import MIMEMultipart
import smtplib
import os
import datetime
import storeFileFB

led = LED(18)
button = Button(22)
camera = PiCamera()

button.when_pressed = led.on
button.when_released = led.off

def send_mail(eFrom, to, subject, text, attachment):
    # SMTP Server details: update to your credentials or use class server
    smtpServer='smtp.mailgun.org'
    smtpUser='postmaster@sandbox6bc45ae5ebab4ebe9246539a6bc28ccf.mailgun.org'
    smtpPassword='01eef86c7564edfe1168945fb4e8a9b2-4879ff27-31455918'
    port=587

    # open attachment and read in as MIME image
    fp = open(attachment, 'rb')
    msgImage = MIMEImage(fp.read())
    fp.close()

    #construct MIME Multipart email message
    msg = MIMEMultipart()
    msg.attach(MIMEText(text))
    msgImage['Content-Disposition'] = 'attachment; filename="image.jpg"'
    msg.attach(msgImage)
    msg['Subject'] = subject

    # Authenticate with SMTP server and send
    s = smtplib.SMTP(smtpServer, port)
    s.login(smtpUser, smtpPassword)
    s.sendmail(eFrom, to, msg.as_string())
    s.quit()

camera.start_preview()
frame = 1

while True:
    button.wait_for_press()

    fileLoc = f'/home/pi/week10/img/frame{frame}.jpg' # set location of image file and current time
    currentTime = datetime.datetime.now().strftime("%d/%m/%Y %H:%M:%S")

    os.system("aplay Dong.wav&") # plays a sound, as all good doorbells should
    camera.capture(fileLoc) # capture image and store in fileLoc
    text= f'Dong! Someone rang your doorbell at {currentTime}, see who it is!'
    send_mail('idwdongdoorbellapp@gmail.com', '20091388@mail.wit.ie', 'Dong! Someone is at the door.', text, fileLoc)
    print(f'frame {frame} taken at {currentTime}') # print frame number to console
    storeFileFB.store_file(fileLoc)
    storeFileFB.push_db(fileLoc, currentTime)
    frame += 1
