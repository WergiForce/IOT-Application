from gpiozero import LED, Button
from picamera import PiCamera
import os
import datetime
import storeFileFB

led = LED(18)
button = Button(22)
camera = PiCamera()

button.when_pressed = led.on #, os.system("aplay Dong.wav&")
# button.when_pressed = os.system("aplay Dong.wav")
button.when_released = led.off

camera.start_preview()
frame = 1

while True:
    button.wait_for_press()

    fileLoc = f'/home/pi/week10/img/frame{frame}.jpg' # set location of image file and current time
    currentTime = datetime.datetime.now().strftime("%d/%m/%Y %H:%M:%S")

    os.system("aplay Dong.wav&")
    camera.capture(fileLoc) # capture image and store in fileLoc
    print(f'frame {frame} taken at {currentTime}') # print frame number to console
    storeFileFB.store_file(fileLoc)
    storeFileFB.push_db(fileLoc, currentTime)
    frame += 1
